import os
import pygame
import random

trigger = False
x = 0
y = 0
height = 720
width = 1280
linelength = 50
lineAmt = 20
displace = 10
xpos = [random.randrange(-200,1280) for i in range(0, lineAmt + 2)]
xpos1 = [(xpos[i]+displace) for i in range(0, lineAmt + 2)]


def setup(screen, etc):
    pass

def draw(screen, etc):
    global trigger, x, y, height, width, xpos, lineAmt, xpos1, linelength, displace 
    
    displace = 10
    linewidth = (height / lineAmt)
    linelength = int(etc.knob2*300+1)
    color = etc.color_picker()
    minus = (etc.knob3*0.5)+0.5
    shadowColor = (etc.bg_color[0]*minus, etc.bg_color[1]*minus, etc.bg_color[2]*minus)
    
    if etc.audio_trig or etc.midi_note_new :
        trigger = True
        
    if trigger == True :
        
        lineAmt = int(etc.knob1*100 + 2)
        xpos = [random.randrange(-200,1280) for i in range(0, lineAmt + 2)]
        xpos1 = [(xpos[i]+displace) for i in range(0, lineAmt + 2)]
    
    for k in range(0, lineAmt + 2) :
       
        x = xpos1[k] + linelength
        y = (k * linewidth) + int(linewidth/2)- 1
        pygame.draw.line(screen, shadowColor, (xpos1[k], y+displace), (x, y+displace), linewidth)
    for j in range(0, lineAmt + 2) :
       
        x = xpos[j] + linelength
        y = (j * linewidth) + int(linewidth/2)- 1
        pygame.draw.line(screen, color, (xpos[j], y), (x, y), linewidth)        
    trigger = False  
    
    
        
    
